/**
 * UI Components Module (ui.js)
 * Clean, accessible UI helpers for SkillFlex Kids.
 */

const $ = (s) => document.querySelector(s);

/**
 * Announce a message for screen readers without visual noise.
 */
export function announceLive(text) {
  const live = document.createElement('div');
  live.className = 'sr-only';
  live.setAttribute('aria-live', 'polite');
  live.textContent = text;
  document.body.appendChild(live);
  setTimeout(() => live.remove(), 600);
}

/**
 * Simple focus trap for a modal container. Returns a cleanup fn.
 */
function trapFocus(modalEl) {
  const FOCUSABLE =
    'a[href], button:not([disabled]), textarea, input, select, [tabindex]:not([tabindex="-1"])';
  let focusables = Array.from(modalEl.querySelectorAll(FOCUSABLE));
  const first = focusables[0];
  const last = focusables[focusables.length - 1];

  function onKey(e) {
    if (e.key !== 'Tab') return;
    // Refresh in case DOM changed
    focusables = Array.from(modalEl.querySelectorAll(FOCUSABLE));
    if (focusables.length === 0) return;
    const firstNow = focusables[0];
    const lastNow = focusables[focusables.length - 1];

    if (e.shiftKey && document.activeElement === firstNow) {
      e.preventDefault();
      lastNow.focus();
    } else if (!e.shiftKey && document.activeElement === lastNow) {
      e.preventDefault();
      firstNow.focus();
    }
  }

  modalEl.addEventListener('keydown', onKey);
  return () => modalEl.removeEventListener('keydown', onKey);
}

/**
 * Lock/unlock page scroll while a modal is open.
 */
function lockScroll() {
  const prev = document.body.style.overflow;
  document.body.style.overflow = 'hidden';
  return () => {
    document.body.style.overflow = prev;
  };
}

/**
 * Kid-friendly nudge shown when trying to save before any progress exists.
 */
export function showSaveNudge(onStart) {
  const host = document.querySelector('#modal-host');
  if (!host) return alert('Finish one activity first to save your coins!');

  host.innerHTML = `
    <div class="modal-overlay" data-modal-overlay>
      <div class="modal-content" role="dialog" aria-modal="true"
           aria-labelledby="nudge-title" aria-describedby="nudge-desc">
        <h2 id="nudge-title" class="modal-title">Almost there! ✨</h2>
        <p id="nudge-desc" class="modal-text">
          Do one quick challenge to earn your first 🪙. Then you can save your coins forever!
        </p>
        <div style="display:flex; gap:.75rem; justify-content:center; flex-wrap:wrap">
          <button id="nudge-start" class="btn btn-primary" type="button">Pick a challenge</button>
          <button id="nudge-close" class="btn btn-secondary" type="button">Got it</button>
        </div>
      </div>
    </div>
  `;

  const overlay = host.querySelector('[data-modal-overlay]');
  const content = host.querySelector('.modal-content');
  const releaseFocus = trapFocus(content);
  const unlock = lockScroll();

  const close = () => {
    releaseFocus();
    unlock();
    host.innerHTML = '';
  };

  host.querySelector('#nudge-close').onclick = close;
  host.querySelector('#nudge-start').onclick = () => {
    close();
    onStart?.();
  };
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) close();
  });
  overlay.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') close();
  });

  // Focus first action, announce
  (host.querySelector('#nudge-start') || content).focus();
  announceLive('Finish one activity to save your coins.');
}

/**
 * Completion modal (accessible, keyboard friendly).
 * @param {number} score
 * @param {number} total
 * @param {function} onContinue
 * @param {object}   extra      optional { onSave: function }
 */
export function showCompletionModal(score, total, onContinue, extra = {}) {
  const modalHost = document.querySelector('#modal-host');
  if (!modalHost) {
    console.error('Modal host element not found!');
    // If we can’t show a modal, just go home.
    try {
      history.pushState({}, '', '/');
      if (typeof window.router === 'function') window.router();
    } catch {}
    return;
  }

  // Friendly headline based on score
  const pct = total > 0 ? Math.round((score / total) * 100) : 0;
  let title = 'Good Effort!';
  let subtitle = 'Every bit of practice helps you grow stronger!';
  if (pct >= 90) {
    title = 'Incredible! 🌟';
    subtitle = "You're a true learning superstar!";
  } else if (pct >= 50) {
    title = 'Well Done! 🎉';
    subtitle = 'That was a fantastic job. Keep it up!';
  }

  const showSave = typeof extra.onSave === 'function';
  const showNext = typeof onContinue === 'function';

  // Build modal
  modalHost.innerHTML = `
    <div class="modal-overlay" data-modal-overlay>
      <div class="modal-content" role="dialog" aria-modal="true"
           aria-labelledby="modal-title" aria-describedby="modal-desc">
        <h2 id="modal-title" class="modal-title">${title}</h2>
        <p id="modal-desc" class="modal-text">${subtitle}</p>

        <div class="modal-score">You scored: <strong>${score} / ${total}</strong></div>

        <div class="modal-actions" style="display:flex; gap:.75rem; justify-content:center; flex-wrap:wrap">
          ${showSave ? `<button id="modal-save" class="btn btn-primary" type="button">Save my coins 🪙</button>` : ''}
          ${showNext ? `<button id="modal-next" class="btn btn-primary" type="button">Continue ▶</button>` : ''}
          <button id="modal-back" class="btn btn-secondary" type="button">Back to hub</button>
        </div>
      </div>
    </div>
  `;

  // Focus management + scroll lock (helpers already defined above in your file)
  const overlay  = modalHost.querySelector('[data-modal-overlay]');
  const content  = modalHost.querySelector('.modal-content');
  const btnSave  = modalHost.querySelector('#modal-save');
  const btnNext  = modalHost.querySelector('#modal-next');
  const btnBack  = modalHost.querySelector('#modal-back');
  const prevFocus = document.activeElement;

  const releaseFocus = (function trapFocus(modalEl){
    const FOCUSABLE = 'a[href], button:not([disabled]), textarea, input, select, [tabindex]:not([tabindex="-1"])';
    const onKey = (e) => {
      if (e.key !== 'Tab') return;
      const list = Array.from(modalEl.querySelectorAll(FOCUSABLE));
      if (!list.length) return;
      const first = list[0], last = list[list.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    };
    modalEl.addEventListener('keydown', onKey);
    return () => modalEl.removeEventListener('keydown', onKey);
  })(content);

  const unlock = (function lockScroll(){
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = prev; };
  })();

  function cleanup() {
    releaseFocus();
    unlock();
    modalHost.innerHTML = '';
    try { prevFocus && prevFocus.focus?.(); } catch {}
  }

  // Always go back to the hub
  function goHome() {
    cleanup();
    document.body.classList.remove('in-lesson');
    document.getElementById('app')?.classList.remove('lesson-active');
    history.pushState({}, '', '/');
    if (typeof window.router === 'function') window.router();
  }

  // Wire buttons
  btnBack.addEventListener('click', goHome);

  if (btnNext && showNext) {
    btnNext.addEventListener('click', async () => {
      cleanup();
      try { await onContinue(); } catch {}
    });
  }

  if (btnSave && showSave) {
    btnSave.addEventListener('click', (e) => {
      e.preventDefault();
      // Keep modal visible; the save handler will navigate to login.
      try { extra.onSave(); } catch {}
    });
  }

  // Dismissals → also go home
  overlay.addEventListener('click', (e) => { if (e.target === overlay) goHome(); });
  overlay.addEventListener('keydown', (e) => { if (e.key === 'Escape') goHome(); });

  // Initial focus + SR announce
  (btnSave || btnNext || btnBack).focus();
  (function announceLive(text){
    const live = document.createElement('div');
    live.className = 'sr-only';
    live.setAttribute('aria-live', 'polite');
    live.textContent = text;
    document.body.appendChild(live);
    setTimeout(() => live.remove(), 600);
  })('Lesson complete. Choose Save, Continue, or Back to hub.');
}
