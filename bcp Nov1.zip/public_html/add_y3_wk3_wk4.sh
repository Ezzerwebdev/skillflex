#!/usr/bin/env bash
set -euo pipefail
umask 022

ROOT=~/www/games.skillflex.education/public_html
PACKDIR="$ROOT/packs/year3/english/spelling"
REG="$ROOT/custom_activities.json"
BKP="$ROOT/_backups"; mkdir -p "$PACKDIR" "$BKP"

echo "== SkillFlex: Y3 Spelling — Weeks 3 & 4 (10 packs) =="

# --- helpers ---------------------------------------------------------------
write_pack () {
  local slug="$1"
  local path="$PACKDIR/$slug.json"
  if [[ -f "$path" ]]; then
    echo "SKIP pack (exists) $slug"
    return 0
  fi
  mkdir -p "$PACKDIR"
  cat > "$path"
  chmod 644 "$path"
  echo "WROTE $slug"
}

# Build one registry patch (we'll merge once at the end)
PATCH="$(mktemp)"
cat > "$PATCH" <<'JSON'
[
  { "id":"year3/english/spelling/sub-word-builder-y3",   "title":"Sub Word Builder",      "subject":"english","year":3,"level":"seedling","topic":"spelling","icon":"🔡" },
  { "id":"year3/english/spelling/super-spot-the-error-y3","title":"Super Spot the Error", "subject":"english","year":3,"level":"seedling","topic":"spelling","icon":"🔡" },
  { "id":"year3/english/spelling/auto-meaning-match-y3", "title":"Auto Meaning Match",    "subject":"english","year":3,"level":"seedling","topic":"spelling","icon":"🔡" },
  { "id":"year3/english/spelling/anti-fill-the-gap-y3",  "title":"Anti Fill the Gap",     "subject":"english","year":3,"level":"seedling","topic":"spelling","icon":"🔡" },
  { "id":"year3/english/spelling/to-too-two-choices-y3", "title":"To/Too/Two Choices",    "subject":"english","year":3,"level":"seedling","topic":"spelling","icon":"🔡" },

  { "id":"year3/english/spelling/suffix-ful-maker-y3",   "title":"-ful Maker",            "subject":"english","year":3,"level":"seedling","topic":"spelling","icon":"🔡" },
  { "id":"year3/english/spelling/suffix-less-spot-y3",   "title":"-less Spotter",         "subject":"english","year":3,"level":"seedling","topic":"spelling","icon":"🔡" },
  { "id":"year3/english/spelling/suffix-ment-builder-y3","title":"-ment Builder",         "subject":"english","year":3,"level":"seedling","topic":"spelling","icon":"🔡" },
  { "id":"year3/english/spelling/ness-ly-truth-check-y3","title":"-ness/-ly Truth Check", "subject":"english","year":3,"level":"seedling","topic":"spelling","icon":"🔡" },
  { "id":"year3/english/spelling/there-their-theyre-y3", "title":"There/Their/They're",   "subject":"english","year":3,"level":"seedling","topic":"spelling","icon":"🔡" }
]
JSON

# --- write packs (Weeks 3 & 4) ---------------------------------------------

# 1) sub-word-builder-y3
write_pack sub-word-builder-y3 <<'JSON'
{
  "id":"year3/english/spelling/sub-word-builder-y3",
  "title":"Sub Word Builder",
  "version":1,
  "steps":[
    {"id":"s1","type":"select_option","prompt":"Which word means a vehicle that travels under the sea?","options":[{"text":"submarine"},{"text":"subtitle"},{"text":"subway"}],"answer":0},
    {"id":"s2","type":"fill_blank","prompt":"Type the word that means a heading under a picture:","answer":"subtitle"},
    {"id":"s3","type":"order_words","prompt":"Build the word: sub + marine","words":["sub","marine"],"answer":["sub","marine"]},
    {"id":"s4","type":"true_false","prompt":"The prefix 'sub-' can mean 'under' or 'below'.","answer":true}
  ]
}
JSON

# 2) super-spot-the-error-y3
write_pack super-spot-the-error-y3 <<'JSON'
{
  "id":"year3/english/spelling/super-spot-the-error-y3",
  "title":"Super Spot the Error",
  "version":1,
  "steps":[
    {"id":"s1","type":"select_option","prompt":"Choose the correct spelling:","options":[{"text":"suprhero"},{"text":"superhero"},{"text":"super-heerow"}],"answer":1},
    {"id":"s2","type":"true_false","prompt":"The word 'superman' uses the prefix 'super-'.","answer":true},
    {"id":"s3","type":"fill_blank","prompt":"Type the word that means 'very fast': ______fast","answer":"superfast"},
    {"id":"s4","type":"select_option","prompt":"Which uses the prefix 'super-'?","options":[{"text":"superstar"},{"text":"surprise"},{"text":"supersition"}],"answer":0}
  ]
}
JSON

# 3) auto-meaning-match-y3
write_pack auto-meaning-match-y3 <<'JSON'
{
  "id":"year3/english/spelling/auto-meaning-match-y3",
  "title":"Auto Meaning Match",
  "version":1,
  "steps":[
    {"id":"s1","type":"match_pairs","leftLabel":"Word","rightLabel":"Meaning","pairs":[
      {"left":"autograph","right":"a person's own signature"},
      {"left":"autopilot","right":"controls by itself"},
      {"left":"automatic","right":"works by itself"}
    ]},
    {"id":"s2","type":"select_option","prompt":"In 'autopilot', 'auto-' means…","options":[{"text":"self / by itself"},{"text":"together"},{"text":"back"}],"answer":0},
    {"id":"s3","type":"true_false","prompt":"'Autograph' is a machine that writes by itself.","answer":false}
  ]
}
JSON

# 4) anti-fill-the-gap-y3
write_pack anti-fill-the-gap-y3 <<'JSON'
{
  "id":"year3/english/spelling/anti-fill-the-gap-y3",
  "title":"Anti Fill the Gap",
  "version":1,
  "steps":[
    {"id":"s1","type":"fill_blank","prompt":"Opposite of 'clockwise' is ______clockwise.","answer":"anticlockwise"},
    {"id":"s2","type":"select_option","prompt":"Which word means a medicine that fights bacteria?","options":[{"text":"antibiotics"},{"text":"antifreeze"},{"text":"antihair"}],"answer":0},
    {"id":"s3","type":"true_false","prompt":"'Antifreeze' stops water from freezing.","answer":true},
    {"id":"s4","type":"order_words","prompt":"Build the word: anti + viral","words":["anti","viral"],"answer":["anti","viral"]}
  ]
}
JSON

# 5) to-too-two-choices-y3
write_pack to-too-two-choices-y3 <<'JSON'
{
  "id":"year3/english/spelling/to-too-two-choices-y3",
  "title":"To/Too/Two Choices",
  "version":1,
  "steps":[
    {"id":"s1","type":"select_option","prompt":"I have ____ apples.","options":[{"text":"to"},{"text":"too"},{"text":"two"}],"answer":2},
    {"id":"s2","type":"select_option","prompt":"It's time ____ go home.","options":[{"text":"to"},{"text":"too"},{"text":"two"}],"answer":0},
    {"id":"s3","type":"select_option","prompt":"This bag is ____ heavy.","options":[{"text":"to"},{"text":"too"},{"text":"two"}],"answer":1},
    {"id":"s4","type":"true_false","prompt":"We spell the number 2 as 'too'.","answer":false}
  ]
}
JSON

# 6) suffix-ful-maker-y3
write_pack suffix-ful-maker-y3 <<'JSON'
{
  "id":"year3/english/spelling/suffix-ful-maker-y3",
  "title":"-ful Maker",
  "version":1,
  "steps":[
    {"id":"s1","type":"match_pairs","leftLabel":"Base","rightLabel":"With -ful","pairs":[
      {"left":"help","right":"helpful"},
      {"left":"use","right":"useful"},
      {"left":"care","right":"careful"}
    ]},
    {"id":"s2","type":"select_option","prompt":"Pick the correct -ful word for 'full of pain':","options":[{"text":"painful"},{"text":"painfull"},{"text":"paneful"}],"answer":0},
    {"id":"s3","type":"true_false","prompt":"We spell it 'carefull' with two l's.","answer":false}
  ]
}
JSON

# 7) suffix-less-spot-y3
write_pack suffix-less-spot-y3 <<'JSON'
{
  "id":"year3/english/spelling/suffix-less-spot-y3",
  "title":"-less Spotter",
  "version":1,
  "steps":[
    {"id":"s1","type":"select_option","prompt":"Choose the correct spelling: 'without fear'.","options":[{"text":"fearless"},{"text":"fearles"},{"text":"fear less"}],"answer":0},
    {"id":"s2","type":"fill_blank","prompt":"Write the word that means 'without hope':","answer":"hopeless"},
    {"id":"s3","type":"true_false","prompt":"The suffix 'less' means 'with extra'.","answer":false},
    {"id":"s4","type":"order_words","prompt":"Build the word: care + less","words":["care","less"],"answer":["care","less"]}
  ]
}
JSON

# 8) suffix-ment-builder-y3
write_pack suffix-ment-builder-y3 <<'JSON'
{
  "id":"year3/english/spelling/suffix-ment-builder-y3",
  "title":"-ment Builder",
  "version":1,
  "steps":[
    {"id":"s1","type":"match_pairs","leftLabel":"Verb","rightLabel":"Noun (-ment)","pairs":[
      {"left":"enjoy","right":"enjoyment"},
      {"left":"move","right":"movement"},
      {"left":"agree","right":"agreement"}
    ]},
    {"id":"s2","type":"select_option","prompt":"Which is correct?","options":[{"text":"enjoyement"},{"text":"enjoyment"},{"text":"enjoymant"}],"answer":1},
    {"id":"s3","type":"true_false","prompt":"The suffix '-ment' can turn a verb into a noun.","answer":true}
  ]
}
JSON

# 9) ness-ly-truth-check-y3
write_pack ness-ly-truth-check-y3 <<'JSON'
{
  "id":"year3/english/spelling/ness-ly-truth-check-y3",
  "title":"-ness/-ly Truth Check",
  "version":1,
  "steps":[
    {"id":"s1","type":"true_false","prompt":"'kind' + 'ness' = 'kindness'.","answer":true},
    {"id":"s2","type":"select_option","prompt":"Choose the adverb (-ly):","options":[{"text":"slowly"},{"text":"slow"},{"text":"slowness"}],"answer":0},
    {"id":"s3","type":"fill_blank","prompt":"Add -ly: quick → ______","answer":"quickly"},
    {"id":"s4","type":"select_option","prompt":"Which is a noun made with -ness?","options":[{"text":"happy"},{"text":"happiness"},{"text":"happily"}],"answer":1}
  ]
}
JSON

# 10) there-their-theyre-y3
write_pack there-their-theyre-y3 <<'JSON'
{
  "id":"year3/english/spelling/there-their-theyre-y3",
  "title":"There/Their/They're",
  "version":1,
  "steps":[
    {"id":"s1","type":"select_option","prompt":"______ going to the park.","options":[{"text":"There"},{"text":"Their"},{"text":"They're"}],"answer":2},
    {"id":"s2","type":"select_option","prompt":"Put your bag over ______.","options":[{"text":"there"},{"text":"their"},{"text":"they're"}],"answer":0},
    {"id":"s3","type":"select_option","prompt":"Is this ______ house?","options":[{"text":"there"},{"text":"their"},{"text":"they're"}],"answer":1},
    {"id":"s4","type":"true_false","prompt":"'They're' means 'they are'.","answer":true}
  ]
}
JSON

# --- merge registry (dedupe by id) -----------------------------------------
cp "$REG" "$BKP/custom_activities.json.$(date +%s).bak"
tmp="$(mktemp)"
jq -s '[.[0][] , .[1][]] | group_by(.id) | map(.[-1])' "$REG" "$PATCH" > "$tmp"
mv "$tmp" "$REG"
chmod 644 "$REG"

# --- perms & cache-bust -----------------------------------------------------
# Ensure dirs/files have safe perms
find "$ROOT/packs" -type d -exec chmod 755 {} +
find "$ROOT/packs" -type f -name '*.json' -exec chmod 644 {} +
# Nudge caches (CDN/browser/SW)
touch "$ROOT/app.js"

# --- verify ---------------------------------------------------------------
SLUGS=( sub-word-builder-y3 super-spot-the-error-y3 auto-meaning-match-y3 anti-fill-the-gap-y3 to-too-two-choices-y3 \
        suffix-ful-maker-y3 suffix-less-spot-y3 suffix-ment-builder-y3 ness-ly-truth-check-y3 there-their-theyre-y3 )

echo "---- File presence + id/path match ----"
for s in "${SLUGS[@]}"; do
  f="$PACKDIR/$s.json"
  [[ -f "$f" ]] || { echo "MISS file $s"; continue; }
  if jq -e . "$f" >/dev/null; then
    expect="year3/english/spelling/$s"
    actual="$(jq -r '.id' "$f")"
    [[ "$actual" == "$expect" ]] && echo "OK   file  $s" || echo "MISMATCH id $s ($actual != $expect)"
  else
    echo "BAD  json  $s"
  fi
done

echo "---- Registry contains all IDs ----"
for s in "${SLUGS[@]}"; do
  id="year3/english/spelling/$s"
  if jq -e --arg id "$id" 'any(.[]; .id==$id)' "$REG" >/dev/null; then
    echo "OK   reg   $s"
  else
    echo "MISS reg  $s"
  fi
done

echo "---- HTTP reachability (200=good) ----"
for s in "${SLUGS[@]}"; do
  url="https://games.skillflex.education/packs/year3/english/spelling/$s.json"
  code=$(curl -s -o /dev/null -w "%{http_code}" "$url")
  echo "$code  $s"
done

echo "✅ Done. If the hub looks stale, hard-reload or unregister the SW."
