#!/usr/bin/env bash
set -euo pipefail

ROOT="${ROOT:-$PWD}"
REG="$ROOT/custom_activities.json"
PACKDIR="$ROOT/packs/year3/english/spelling"
BKP="$ROOT/_backups"; mkdir -p "$BKP" "$PACKDIR"

[[ -f "$REG" ]] || { echo "❌ Run this from public_html or set ROOT"; exit 1; }

cp "$REG" "$BKP/custom_activities.json.$(date +%s).bak" || true
for f in ei-meaning-match-y3.json match-advanced-y3.json; do
  [[ -f "$PACKDIR/$f" ]] && cp "$PACKDIR/$f" "$BKP/$f.$(date +%s).bak" || true
done

# --- rewrite the two packs with schema-clean JSON ---

cat > "$PACKDIR/ei-meaning-match-y3.json" <<'JSON'
{
  "id":"year3/english/spelling/ei-meaning-match-y3",
  "title":"EI Meaning Match",
  "version":1,
  "steps":[
    { "id":"s1","type":"match_pairs","leftLabel":"Word","rightLabel":"Meaning",
      "pairs":[
        {"left":"rein","right":"strap to guide a horse"},
        {"left":"vein","right":"a blood vessel"},
        {"left":"sleigh","right":"snow vehicle"},
        {"left":"beige","right":"a light brown colour"}
      ]},
    { "id":"s2","type":"select_option","prompt":"Pick the correct spelling:",
      "options":[{"text":"sleygh"},{"text":"sleigh"},{"text":"sleig"}],"answer":1 },
    { "id":"s3","type":"fill_blank","prompt":"Type the homophone for ‘rein’ (the weather one):",
      "answer":["rain"] },
    { "id":"s4","type":"true_false","prompt":"‘Vein’ is a strap used to control a horse.","answer":false }
  ]
}
JSON

cat > "$PACKDIR/match-advanced-y3.json" <<'JSON'
{
  "id":"year3/english/spelling/match-advanced-y3",
  "title":"Match Advanced (Prefixes & Suffixes)",
  "version":1,
  "steps":[
    { "id":"s1","type":"match_pairs","leftLabel":"Affix","rightLabel":"Meaning",
      "pairs":[
        {"left":"prefix ‘un-’","right":"means ‘not’ / ‘opposite of’"},
        {"left":"prefix ‘re-’","right":"means ‘again’"},
        {"left":"suffix ‘-ful’","right":"means ‘full of’"},
        {"left":"suffix ‘-less’","right":"means ‘without’"}
      ]},
    { "id":"s2","type":"select_option","prompt":"Which word uses the prefix ‘re-’ correctly?",
      "options":[{"text":"redo"},{"text":"red"},{"text":"reed"}],"answer":0 },
    { "id":"s3","type":"fill_blank","prompt":"Add the correct suffix to make ‘help’ mean ‘without help’. Type the whole word.",
      "answer":["helpless"] },
    { "id":"s4","type":"true_false","prompt":"‘un-’ can attach to ‘happy’ to mean ‘not happy’.","answer":true }
  ]
}
JSON

chmod 644 "$PACKDIR/ei-meaning-match-y3.json" "$PACKDIR/match-advanced-y3.json"

# drop the dev artefact from registry if present
tmp=$(mktemp)
jq 'map(select(.id!="year3/english/spelling/match-test"))' "$REG" > "$tmp" && mv "$tmp" "$REG"

# normalise perms (safe)
find "$ROOT" -type d -exec chmod 755 {} + 2>/dev/null || true
find "$ROOT" -type f \( -name '*.json' -o -name '*.js' -o -name '*.css' -o -name '*.html' \) -exec chmod 644 {} + 2>/dev/null || true

# bump SW so clients pick latest
touch "$ROOT/app.js"
echo "✅ Fixed packs + cleaned registry + perms OK + cache-busted."
