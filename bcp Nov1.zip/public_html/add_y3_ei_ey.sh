#!/usr/bin/env bash
set -euo pipefail
umask 022

ROOT=~/www/games.skillflex.education/public_html
PACKDIR="$ROOT/packs/year3/english/spelling"
REG="$ROOT/custom_activities.json"
BKP="$ROOT/_backups"

mkdir -p "$PACKDIR" "$BKP"
cp "$REG" "$BKP/custom_activities.json.$(date +%s).bak" || true

write_pack() {
  local slug="$1"
  local path="$PACKDIR/$slug.json"
  if [[ -f "$path" && "${FORCE_OVERWRITE:-0}" != "1" ]]; then
    echo "SKIP pack (exists) $slug"
    return 0
  fi
  cat > "$path"
  chmod 644 "$path"
  echo "WROTE $slug"
}

# -------- EI week (ei) --------

write_pack ei-word-builder-y3 <<'JSON'
{ "id":"year3/english/spelling/ei-word-builder-y3","title":"Word Builder: ei","version":1,"steps":[
  {"id":"s1","type":"order_words","prompt":"Build the word: \"weigh\"","words":["w","e","i","g","h"],"answer":["w","e","i","g","h"]},
  {"id":"s2","type":"select_option","prompt":"Choose the correct spelling","options":[{"text":"vein"},{"text":"vain"},{"text":"vane"}],"answer":0},
  {"id":"s3","type":"order_words","prompt":"Build the word: \"neighbour\"","words":["n","e","i","g","h","b","o","u","r"],"answer":["n","e","i","g","h","b","o","u","r"]}
]}
JSON

write_pack ei-spot-the-error-y3 <<'JSON'
{ "id":"year3/english/spelling/ei-spot-the-error-y3","title":"EI Spot the Error","version":1,"steps":[
  {"id":"s1","type":"select_option","prompt":"Choose the correct spelling","options":[{"text":"weigth"},{"text":"weight"},{"text":"weitgh"}],"answer":1},
  {"id":"s2","type":"select_option","prompt":"Choose the correct spelling","options":[{"text":"vail"},{"text":"veil"},{"text":"vale"}],"answer":1},
  {"id":"s3","type":"true_false","prompt":"\"rein\" is used to control a horse.","answer":true},
  {"id":"s4","type":"true_false","prompt":"\"vein\" and \"rein\" mean the same thing.","answer":false}
]}
JSON

write_pack ei-fill-the-gap-y3 <<'JSON'
{ "id":"year3/english/spelling/ei-fill-the-gap-y3","title":"EI Fill the Gaps","version":1,"steps":[
  {"id":"s1","type":"select_option","prompt":"Blood flows through a ___.","options":[{"text":"vain"},{"text":"vein"},{"text":"rein"}],"answer":1},
  {"id":"s2","type":"select_option","prompt":"She wore a white ___.","options":[{"text":"vail"},{"text":"vale"},{"text":"veil"}],"answer":2},
  {"id":"s3","type":"fill_blank","prompt":"The suitcase is very ___ (spell it).","answer":["heavy"]},
  {"id":"s4","type":"select_option","prompt":"We live next to our ___.","options":[{"text":"neighbor"},{"text":"neighbour"},{"text":"naybour"}],"answer":1}
]}
JSON

write_pack ei-meaning-match-y3 <<'JSON'
{ "id":"year3/english/spelling/ei-meaning-match-y3","title":"EI Meaning Match","version":1,"steps":[
  {"id":"mp1","type":"match_pairs","leftLabel":"Word","rightLabel":"Meaning","pairs":[
    {"left":"rein","right":"strap to guide a horse"},
    {"left":"vein","right":"tube that carries blood"},
    {"left":"veil","right":"covering worn on the head/face"}
  ]},
  {"id":"s2","type":"true_false","prompt":"A \"rein\" and a \"vein\" are homophones.","answer":true}
]}
JSON

write_pack ei-truth-check-y3 <<'JSON'
{ "id":"year3/english/spelling/ei-truth-check-y3","title":"EI True/False","version":1,"steps":[
  {"id":"t1","type":"true_false","prompt":"\"weigh\" contains the letters e-i.","answer":true},
  {"id":"t2","type":"true_false","prompt":"\"neighbour\" is spelled the same in US and UK English.","answer":false},
  {"id":"t3","type":"true_false","prompt":"\"vein\" is a body part.","answer":true},
  {"id":"t4","type":"true_false","prompt":"\"rein\" is a kind of weather.","answer":false}
]}
JSON

# -------- EY week (ey) --------

write_pack ey-word-builder-y3 <<'JSON'
{ "id":"year3/english/spelling/ey-word-builder-y3","title":"Word Builder: ey","version":1,"steps":[
  {"id":"s1","type":"order_words","prompt":"Build the word: \"money\"","words":["m","o","n","e","y"],"answer":["m","o","n","e","y"]},
  {"id":"s2","type":"order_words","prompt":"Build the word: \"monkey\"","words":["m","o","n","k","e","y"],"answer":["m","o","n","k","e","y"]},
  {"id":"s3","type":"select_option","prompt":"Choose the correct spelling","options":[{"text":"turky"},{"text":"turkey"},{"text":"turkie"}],"answer":1}
]}
JSON

write_pack ey-spot-the-error-y3 <<'JSON'
{ "id":"year3/english/spelling/ey-spot-the-error-y3","title":"EY Spot the Error","version":1,"steps":[
  {"id":"s1","type":"select_option","prompt":"Choose the correct spelling","options":[{"text":"journy"},{"text":"journey"},{"text":"jorney"}],"answer":1},
  {"id":"s2","type":"select_option","prompt":"Choose the correct spelling","options":[{"text":"chimny"},{"text":"chimney"},{"text":"chimnay"}],"answer":1},
  {"id":"s3","type":"true_false","prompt":"\"money\" ends with -ey.","answer":true}
]}
JSON

write_pack ey-fill-the-gap-y3 <<'JSON'
{ "id":"year3/english/spelling/ey-fill-the-gap-y3","title":"EY Fill the Gaps","version":1,"steps":[
  {"id":"s1","type":"select_option","prompt":"The ___ climbed the tree.","options":[{"text":"monky"},{"text":"monkey"},{"text":"monkay"}],"answer":1},
  {"id":"s2","type":"select_option","prompt":"Put the book on the ___.","options":[{"text":"valley"},{"text":"journey"},{"text":"trolley"}],"answer":2},
  {"id":"s3","type":"fill_blank","prompt":"We saved our pocket ___ for a toy.","answer":["money"]}
]}
JSON

write_pack ey-letter-order-y3 <<'JSON'
{ "id":"year3/english/spelling/ey-letter-order-y3","title":"EY Letter Order","version":1,"steps":[
  {"id":"s1","type":"order_words","prompt":"Build the word: \"donkey\"","words":["d","o","n","k","e","y"],"answer":["d","o","n","k","e","y"]},
  {"id":"s2","type":"order_words","prompt":"Build the word: \"valley\"","words":["v","a","l","l","e","y"],"answer":["v","a","l","l","e","y"]},
  {"id":"s3","type":"order_words","prompt":"Build the word: \"hockey\"","words":["h","o","c","k","e","y"],"answer":["h","o","c","k","e","y"]}
]}
JSON

write_pack ey-truth-check-y3 <<'JSON'
{ "id":"year3/english/spelling/ey-truth-check-y3","title":"EY True/False","version":1,"steps":[
  {"id":"t1","type":"true_false","prompt":"\"journey\" ends with -ey.","answer":true},
  {"id":"t2","type":"true_false","prompt":"\"monkey\" is spelled monkie.","answer":false},
  {"id":"t3","type":"true_false","prompt":"\"chimney\" has the letters n-e-y at the end.","answer":true}
]}
JSON

# -------- Registry patch (dedup by .id) --------
PATCH="$(mktemp)"
cat > "$PATCH" <<'JSON'
[
  { "id":"year3/english/spelling/ei-word-builder-y3",   "title":"Word Builder: ei",   "subject":"english","year":3,"level":"seedling","topic":"spelling","icon":"🔡" },
  { "id":"year3/english/spelling/ei-spot-the-error-y3", "title":"EI Spot the Error",  "subject":"english","year":3,"level":"seedling","topic":"spelling","icon":"🛑" },
  { "id":"year3/english/spelling/ei-fill-the-gap-y3",   "title":"EI Fill the Gaps",   "subject":"english","year":3,"level":"seedling","topic":"spelling","icon":"🧩" },
  { "id":"year3/english/spelling/ei-meaning-match-y3",  "title":"EI Meaning Match",   "subject":"english","year":3,"level":"sprout",  "topic":"spelling","icon":"🤝" },
  { "id":"year3/english/spelling/ei-truth-check-y3",    "title":"EI True/False",      "subject":"english","year":3,"level":"seedling","topic":"spelling","icon":"⚖️" },
  { "id":"year3/english/spelling/ey-word-builder-y3",   "title":"Word Builder: ey",   "subject":"english","year":3,"level":"seedling","topic":"spelling","icon":"🔡" },
  { "id":"year3/english/spelling/ey-spot-the-error-y3", "title":"EY Spot the Error",  "subject":"english","year":3,"level":"seedling","topic":"spelling","icon":"🛑" },
  { "id":"year3/english/spelling/ey-fill-the-gap-y3",   "title":"EY Fill the Gaps",   "subject":"english","year":3,"level":"seedling","topic":"spelling","icon":"🧩" },
  { "id":"year3/english/spelling/ey-letter-order-y3",   "title":"EY Letter Order",    "subject":"english","year":3,"level":"seedling","topic":"spelling","icon":"🔤" },
  { "id":"year3/english/spelling/ey-truth-check-y3",    "title":"EY True/False",      "subject":"english","year":3,"level":"seedling","topic":"spelling","icon":"⚖️" }
]
JSON

# If registry missing, create a minimal array
[[ -f "$REG" ]] || echo "[]" > "$REG"

tmp=$(mktemp)
jq -s 'add | group_by(.id) | map(.[-1])' "$REG" "$PATCH" > "$tmp"
mv "$tmp" "$REG"

# -------- Quick verify --------
echo "---- VERIFY PACK FILES ----"
SLUGS=( ei-word-builder-y3 ei-spot-the-error-y3 ei-fill-the-gap-y3 ei-meaning-match-y3 ei-truth-check-y3 ey-word-builder-y3 ey-spot-the-error-y3 ey-fill-the-gap-y3 ey-letter-order-y3 ey-truth-check-y3 )
for s in "${SLUGS[@]}"; do
  f="$PACKDIR/$s.json"
  if [[ -f "$f" ]] && jq -e . "$f" >/dev/null; then
    echo "OK  file  $s"
  else
    echo "MISS file $s"
  fi
done

echo "---- VERIFY REGISTRY ----"
for s in "${SLUGS[@]}"; do
  id="year3/english/spelling/$s"
  if jq -e --arg id "$id" 'map(.id) | index($id) != null' "$REG" >/dev/null; then
    echo "OK  reg   $s"
  else
    echo "MISS reg  $s"
  fi
done

# Nudge SW cache
touch "$ROOT/app.js"
echo "✅ Done. If browser still shows old list, hard-reload or unregister SW."
